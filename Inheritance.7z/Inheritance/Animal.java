
public class Animal
{
    String color;
    String numOfLegs;
    
    
    public Animal(){
        
    }
    
    public Animal(String color, String numOfLegs){
        this.color = color;
        this.numOfLegs = numOfLegs;
    }
    
    public String getcolor(){
        return color;
    }
    
    public void setcolor(String color){
        this.color = color;
    }
    
    public String getnumOfLegs(){
        return numOfLegs;
    }
    
    public void setLegs(String numOfLegs){
        this.numOfLegs = numOfLegs;
    }
    
    public void showInfo(){
        System.out.println("The color is " + color);
        System.out.println("The Number of Legs is " + numOfLegs);
    }
    
}
