
public class Dog extends Animal
{
    String dogName;
    
    public Dog(String color, String numOfLegs){
        super(color, numOfLegs);
        this.dogName = ("Pom");
    }
    
    public String getName(){
        return dogName;
    }
    
    public void setName(String dogName){
        this.dogName = dogName;
    }
    

}
