

public class inheritanceTest
{
    public static void main(String []args){
        
        Dog dog1 = new Dog("Whitey", "3");
        System.out.println(dog1.getName());
        System.out.println(dog1.getcolor());
        System.out.println(dog1.getnumOfLegs());
        
        
        
        
        
    }
}
